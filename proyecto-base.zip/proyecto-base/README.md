# Proyecto Base — React + Node/Express

Estructura mínima y funcional con frontend en React (Vite) y backend en Node + Express.

## Estructura

```
proyecto-base/
├── frontend/   → React + Vite (puerto 5173)
└── backend/    → Node + Express (puerto 3001)
```

## Instalación y arranque

### 1. Backend

```bash
cd backend
npm install
npm run dev
```

### 2. Frontend (en otra terminal)

```bash
cd frontend
npm install
npm run dev
```

### 3. Abrir en el navegador

```
http://localhost:5173
```

## Cómo funciona

- El frontend usa el proxy de Vite: las peticiones a `/api/*` se redirigen al backend en `localhost:3001`.
- El endpoint de prueba es `GET /ping` → responde `{ message: "pong", timestamp: "..." }`.
- Pulsa el botón en la UI para verificar la conexión frontend↔backend.

## Próximos pasos sugeridos

- Añadir React Router para navegación
- Añadir una base de datos (SQLite, Supabase, etc.)
- Configurar variables de entorno con `.env`
