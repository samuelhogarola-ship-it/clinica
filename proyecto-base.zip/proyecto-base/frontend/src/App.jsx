import { useState } from 'react';

export default function App() {
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);

  const pingBackend = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ping');
      const data = await res.json();
      setResponse(data);
    } catch (err) {
      setResponse({ error: 'No se pudo conectar con el backend' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Proyecto Base</h1>
      <p style={styles.subtitle}>React + Vite · Node + Express</p>
      <button onClick={pingBackend} disabled={loading} style={styles.button}>
        {loading ? 'Enviando...' : 'Ping al backend'}
      </button>
      {response && (
        <div style={styles.result}>
          <pre>{JSON.stringify(response, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    fontFamily: 'system-ui, sans-serif',
    maxWidth: 480,
    margin: '80px auto',
    textAlign: 'center',
    padding: '0 24px',
  },
  title: { fontSize: 28, fontWeight: 700, marginBottom: 4 },
  subtitle: { color: '#666', marginBottom: 32 },
  button: {
    padding: '10px 24px',
    fontSize: 16,
    backgroundColor: '#0f172a',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    cursor: 'pointer',
  },
  result: {
    marginTop: 24,
    padding: 16,
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    textAlign: 'left',
    fontSize: 14,
  },
};
